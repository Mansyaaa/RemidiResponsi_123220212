/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import Modelhewan.interfaceDAOHewan;
import Modelhewan.ModelTableHewan;
import Modelhewan.ModelHewan;
import Modelhewan.DAOhewan;
import java.util.List;
import java.util.ArrayList;
import zoo212.hewan;
import javax.swing.JOptionPane;

/**
 *
 * @author PC PRAKTIKUM
 */
public class controllerhewan {
    hewan frame;
    interfaceDAOHewan impdatahewan;
    List<ModelHewan> dm;
    
    public controllerhewan(hewan frame){
    this.frame = frame;
    impdatahewan = new DAOhewan();
    dm = impdatahewan.getAll();
    }
    public void isitabel (){
        dm = impdatahewan.getAll();
        ModelTableHewan mm = new ModelTableHewan(dm);
        frame.getTabelhewan().setModel(mm);
    }
    
    public void hapusData(int id) {
         impdatahewan.delete(id);
        
        // Refresh tampilan tabel setelah penghapusan berhasil
        isitabel();
    }
 
    public void updateData(ModelHewan hewan) {
        impdatahewan.update(hewan);
        isitabel(); // Refresh the table data
}

    
}